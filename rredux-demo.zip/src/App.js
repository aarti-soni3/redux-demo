import './App.css';
// import Navbar from './Components/Navbar';
// import Shop from './Components/Shop';
import { useSelector, useDispatch } from 'react-redux';
import { increment, decrement } from './reduxToolKit/Slices/Counter/CounterSlice';

function App() {

  const count = useSelector((state) => state.counter.value);
  const dispatch = useDispatch();

  return (
    <div className="App">
      {/* <Navbar/>
      <Shop/> */}

      <div>
        <h1>{count}</h1>
      </div><br/>
      <button onClick={dispatch(increment())}>inc</button>
      <button onClick={dispatch(decrement())}>dec</button>


    </div>
  );
}

export default App;
